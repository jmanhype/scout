
defmodule Scout.Sampler.TPE do
  @behaviour Scout.Sampler
  @moduledoc """
  Tree-structured Parzen Estimator (univariate) sampler.

  Notes:
  * We model each numeric parameter independently with KDEs for the "good" (top γ) and "bad" sets.
  * We then draw candidate points from the good density and select the argmin of l(x)/g(x) across params.
  * If there are not enough observations, we fall back to RandomSearch.
  * Domains are inferred from prior samples (history) and clamped to observed [min,max] with a small pad.
  * Categorical params are left as provided by the baseline prior (search_space/1 probe).

  Options:
    :gamma          — good fraction (default 0.15)
    :n_candidates   — number of candidates to draw and rank (default 24)
    :min_obs        — minimum completed trials before TPE activates (default 20)
    :bw_floor       — minimum KDE bandwidth fraction of range (default 1.0e-3)
    :seed           — optional RNG seed (for determinism)
  """

  alias Scout.Sampler.RandomSearch

  def init(opts) do
    %{
      gamma: Map.get(opts, :gamma, 0.15),
      n_candidates: Map.get(opts, :n_candidates, 24),
      min_obs: Map.get(opts, :min_obs, 20),
      bw_floor: Map.get(opts, :bw_floor, 1.0e-3),
      goal: Map.get(opts, :goal, :maximize),
      seed: Map.get(opts, :seed)
    }
  end

  def next(space_fun, ix, history, state) do
    # Ensure RNG stability if seed is provided
    if state.seed, do: :rand.seed(:exsss, {state.seed, ix, 13})

    probe = space_fun.(ix)
    # Extract completed numeric observations
    obs =
      history
      |> Enum.filter(&is_number(&1.score))
      |> Enum.map(fn t -> {t.params, t.score} end)

    if length(obs) < state.min_obs do
      {RandomSearch.next(space_fun, ix, history, %{} ) |> elem(0), state}
    else
      numeric_keys =
        probe
        |> Map.keys()
        |> Enum.filter(fn k -> is_number(Map.get(probe, k)) end)

      # Build per-parameter distributions
      dists = Enum.into(numeric_keys, %{}, fn k -> {k, build_kdes(k, obs, state)} end)

      # Draw candidates from good density and choose best by EI proxy: minimize sum log(l/g)
      candidates =
        for _ <- 1..state.n_candidates do
          sample_from_good(probe, numeric_keys, dists, state)
        end

      scored =
        Enum.map(candidates, fn cand ->
          lr = density_ratio_logsum(cand, numeric_keys, dists)
          {lr, cand}
        end)

      {_best_lr, best} = Enum.min_by(scored, fn {lr, _} -> lr end)
      {best, state}
    end
  end

  ## KDE helpers

  defp build_kdes(k, obs, state) do
    # Sort by score according to goal and split by gamma
    sorted =
      case state.goal do
        :minimize -> Enum.sort_by(obs, fn {_p, s} -> s end, :asc)
        _ -> Enum.sort_by(obs, fn {_p, s} -> s end, :desc)
      end

    n = max(length(sorted), 1)
    n_good = max(trunc(state.gamma * n), 1)
    {good, bad} = Enum.split(sorted, n_good)

    good_vals = Enum.map(good, fn {p, _s} -> Map.get(p, k) end) |> Enum.filter(&is_number/1)
    bad_vals  = Enum.map(bad,  fn {p, _s} -> Map.get(p, k) end) |> Enum.filter(&is_number/1)

    range = infer_range(good_vals ++ bad_vals)

    %{
      range: range,
      good: kde_from_samples(good_vals, range, state.bw_floor),
      bad:  kde_from_samples(bad_vals,  range, state.bw_floor)
    }
  end

  defp infer_range([]), do: {0.0, 1.0}
  defp infer_range(xs) do
    min = Enum.min(xs)
    max = Enum.max(xs)
    pad = (max - min) * 0.05 + 1.0e-9
    {min - pad, max + pad}
  end

  defp kde_from_samples([], {a,b}, _floor) do
    %{xs: [0.5*(a+b)], sigmas: [max(1.0e-3, (b-a) * 0.1)]}
  end
  defp kde_from_samples(xs, {a,b}, floor_frac) do
    n = length(xs)
    mean = Enum.sum(xs) / n
    var = Enum.reduce(xs, 0.0, fn x, acc -> acc + :math.pow(x - mean, 2) end) / max(n-1,1)
    std = :math.sqrt(max(var, 1.0e-12))
    iqr = percentile(xs, 0.75) - percentile(xs, 0.25)
    sigma = 0.9 * min(std, iqr/1.34) * :math.pow(n, -0.2)
    sigma = max(sigma, (b-a) * floor_frac)
    %{xs: xs, sigmas: Enum.map(xs, fn _ -> sigma end)}
  end

  defp percentile(xs, p) do
    s = Enum.sort(xs)
    k = trunc(p * (length(s)-1)) |> max(0) |> min(length(s)-1)
    Enum.at(s, k)
  end

  defp pdf(%{xs: xs, sigmas: sigmas}, x) do
    m = length(xs)
    if m == 0 do
      1.0e-9
    else
      Enum.zip(xs, sigmas)
      |> Enum.reduce(0.0, fn {mu, sig}, acc ->
        acc + (1.0 / (:math.sqrt(2.0*:math.pi()) * sig)) * :math.exp(-0.5 * :math.pow((x - mu)/sig, 2))
      end) / m
    end
  end

  defp sample_from_good(prior, numeric_keys, dists, state) do
    Enum.reduce(numeric_keys, prior, fn k, acc ->
      %{range: {a,b}, good: g} = Map.fetch!(dists, k)
      # Sample by picking a good component and drawing from its Gaussian
      {mu, sigma} =
        case g do
          %{xs: xs, sigmas: sigmas} when length(xs) > 0 ->
            i = :rand.uniform(length(xs)) - 1
            {Enum.at(xs, i), Enum.at(sigmas, i)}
          _ -> {0.5*(a+b), max(1.0e-3, (b-a)*0.1)}
        end
      x = clamp(:rand.normal(mu, sigma), a, b)
      Map.put(acc, k, x)
    end)
  end

  defp density_ratio_logsum(candidate, numeric_keys, dists) do
    Enum.reduce(numeric_keys, 0.0, fn k, acc ->
      %{good: g, bad: l} = Map.fetch!(dists, k)
      x = Map.fetch!(candidate, k)
      pg = pdf(g, x) |> max(1.0e-12)
      pl = pdf(l, x) |> max(1.0e-12)
      acc + :math.log(pl/pg)
    end)
  end

  defp clamp(x, a, b) when x < a, do: a
  defp clamp(x, a, b) when x > b, do: b
  defp clamp(x, _a, _b), do: x
end
