defmodule Scout.Sampler.TPE do
  @behaviour Scout.Sampler
  @moduledoc """Univariate TPE (good/bad KDE) — simplified.
Falls back to Random until `min_obs`."""
  alias Scout.Sampler.RandomSearch

  def init(opts) do
    %{
      gamma: Map.get(opts, :gamma, 0.15),
      n_candidates: Map.get(opts, :n_candidates, 24),
      min_obs: Map.get(opts, :min_obs, 20),
      bw_floor: Map.get(opts, :bw_floor, 1.0e-3),
      goal: Map.get(opts, :goal, :maximize),
      seed: Map.get(opts, :seed)
    }
  end

  def next(space_fun, ix, history, state) do
    if length(history) < state.min_obs do
      RandomSearch.next(space_fun, ix, history, state)
    else
      probe = space_fun.(ix)
      numeric = for {k,v} <- probe, is_number(v), do: k
      obs = for t <- history, is_number(t.score), do: {t.params, t.score}
      dists = Map.new(numeric, fn k -> {k, build_kdes(k, obs, state)} end)
      cand =
        for _ <- 1..state.n_candidates do
          Enum.reduce(numeric, probe, fn k, acc ->
            %{range: {a,b}, good: g} = Map.fetch!(dists, k)
            {mu, si} = pick_component(g)
            x = clamp(:rand.normal(mu, si), a, b)
            Map.put(acc, k, x)
          end)
        end
      best = cand |> Enum.min_by(fn c -> ratio_logsum(c, numeric, dists) end)
      {best, state}
    end
  end

  defp build_kdes(k, obs, state) do
    sorted =
      case state.goal do
        :minimize -> Enum.sort_by(obs, fn {_p, s} -> s end, :asc)
        _ -> Enum.sort_by(obs, fn {_p, s} -> s end, :desc)
      end
    n = max(length(sorted), 1)
    n_good = max(trunc(state.gamma * n), 1)
    {good, bad} = Enum.split(sorted, n_good)
    gvals = Enum.map(good, fn {p,_} -> Map.get(p,k) end) |> Enum.filter(&is_number/1)
    bvals = Enum.map(bad,  fn {p,_} -> Map.get(p,k) end) |> Enum.filter(&is_number/1)
    range = infer_range(gvals ++ bvals)
    %{range: range, good: kde(gvals, range), bad: kde(bvals, range)}
  end

  defp kde([], {a,b}), do: %{xs: [0.5*(a+b)], sigmas: [max(1.0e-3,(b-a)*0.1)]}
  defp kde(xs, {a,b}) do
    n = length(xs)
    m = Enum.sum(xs)/n
    var = Enum.reduce(xs, 0.0, fn x, acc -> acc + :math.pow(x-m,2) end) / max(n-1,1)
    std = :math.sqrt(max(var, 1.0e-12))
    sigma = max(0.9*std*(:math.pow(n, -0.2)), (b-a)*1.0e-3)
    %{xs: xs, sigmas: Enum.map(xs, fn _ -> sigma end)}
  end

  defp ratio_logsum(cand, ks, dists) do
    Enum.reduce(ks, 0.0, fn k, acc ->
      %{good: g, bad: l} = Map.fetch!(dists, k)
      x = Map.fetch!(cand, k)
      pg = pdf(g, x) |> max(1.0e-12)
      pl = pdf(l, x) |> max(1.0e-12)
      acc + :math.log(pl/pg)
    end)
  end

  defp pdf(%{xs: xs, sigmas: sigmas}, x) do
    m = length(xs)
    if m == 0, do: 1.0e-9, else: Enum.zip(xs, sigmas) |> Enum.reduce(0.0, fn {mu, si}, acc ->
      acc + (1.0/(si*:math.sqrt(2.0*:math.pi()))) * :math.exp(-0.5 * :math.pow((x-mu)/si, 2))
    end) / m
  end

  defp pick_component(%{xs: xs, sigmas: sigmas}) do
    if xs == [], do: {0.0, 1.0}, else: (i = :rand.uniform(length(xs)) - 1; {Enum.at(xs, i), Enum.at(sigmas, i)})
  end

  defp infer_range([]), do: {0.0, 1.0}
  defp infer_range(xs) do
    min = Enum.min(xs); max = Enum.max(xs); pad = (max-min)*0.05 + 1.0e-9
    {min-pad, max+pad}
  end
  defp clamp(x,a,b) when x<a, do: a
  defp clamp(x,a,b) when x>b, do: b
  defp clamp(x,_a,_b), do: x
end
