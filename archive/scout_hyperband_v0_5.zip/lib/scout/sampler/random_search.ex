defmodule Scout.Sampler.RandomSearch do
  @behaviour Scout.Sampler
  @moduledoc "Uniform random sampler: delegates to search_space/1."
  def init(opts), do: opts || %{}
  def next(space_fun, ix, _history, state), do: {space_fun.(ix), state}
end
