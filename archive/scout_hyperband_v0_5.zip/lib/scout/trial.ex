defmodule Scout.Trial do
  @enforce_keys [:id, :study_id, :params, :bracket]
  defstruct [:id, :study_id, :params, :bracket, score: nil, status: :pending,
             started_at: nil, finished_at: nil, rung: 0, metrics: %{}, error: nil, seed: nil]
end
