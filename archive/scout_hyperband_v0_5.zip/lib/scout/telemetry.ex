defmodule Scout.Telemetry do
  def study_event(type, meas \\ %{}, meta \\ %{}) do
    :telemetry.execute([:scout, :study, type], meas, meta)
  end
  def trial_event(type, meas \\ %{}, meta \\ %{}) do
    :telemetry.execute([:scout, :trial, type], meas, meta)
  end
end
