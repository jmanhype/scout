# Scout v0.5 — Hyperband (proper) + Status

This drop adds a **proper Hyperband pruner** with brackets and SHA rungs, and a `Scout.Status.status/1`
API to report per‑bracket, per‑rung progress.

## How it works
- Configure pruner: `pruner: Scout.Pruner.Hyperband, pruner_opts: %{eta: 3, max_resource: 81}`
- The **iterative executor** assigns a bracket to each trial (round‑robin across `s = 0..s_max`).
- Your objective must be **iterative**: call `report_fun.(score, rung)` at rung 0..s for its bracket.
- The pruner compares your trial’s score against **peers at the same (bracket, rung)** and keeps only the
  top `1/eta` fraction; others are **pruned**.

## Quick demo
```elixir
study = %Scout.Study{
  id: "hb-#{System.unique_integer([:positive])}",
  goal: :maximize,
  max_trials: 36,
  parallelism: 8,
  sampler: Scout.Sampler.RandomSearch,
  pruner: Scout.Pruner.Hyperband,
  pruner_opts: %{eta: 3, max_resource: 27},
  search_space: fn _ix -> %{x: :rand.uniform()} end,
  objective: fn %{x: x}, report ->
    # three rungs for s=2 (if max_resource=27, eta=3 -> s_max=3; bracket may get 0..3 rungs)
    score0 = 1.0 - :math.pow(x-0.2,2); case report.(score0, 0) do :prune -> {:pruned, score0}; _ -> :ok end
    score1 = 1.0 - :math.pow(x-0.6,2); case report.(score1, 1) do :prune -> {:pruned, score1}; _ -> :ok end
    score2 = 1.0 - :math.pow(x-0.9,2); case report.(score2, 2) do :prune -> {:pruned, score2}; _ -> :ok end
    {:ok, score2, %{}}
  end
}
{:ok, res} = Scout.run(study)
IO.inspect(Scout.Status.status(study.id), label: "STATUS")
IO.inspect(res, label: "RESULT")
```

## Notes
- Bracket assignment is **round‑robin** by trial index.
- Keep fraction per rung is `1/eta` independent of bracket; the bracket controls **how many rungs** a trial must survive.
- Storage is ETS; replace `Scout.Store` with Ecto/Oban for durability.
