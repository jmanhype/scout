defmodule Scout.MixProject do
  use Mix.Project
  def project do
    [app: :scout, version: "0.5.0", elixir: "~> 1.15", start_permanent: Mix.env() == :prod, deps: deps()]
  end
  def application, do: [mod: {Scout.Application, []}, extra_applications: [:logger, :crypto, :telemetry]]
  defp deps, do: [{:telemetry, "~> 1.2"}, {:jason, "~> 1.4"}]
end
