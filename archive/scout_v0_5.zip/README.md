# Scout v0.5 (Elixir) — Hyperband + SHA, ETS store

**What is this?**
A minimal, OTP‑native Optuna‑style optimizer with Hyperband pruner, Successive Halving rungs, Random/TPE samplers, ETS storage, and a status API.

## Quickstart

```bash
unzip scout_v0_5.zip -d scout_v0_5
cd scout_v0_5
mix deps.get
iex -S mix
```

```elixir
study = %Scout.Study{
  id: "hb-#{System.unique_integer([:positive])}",
  goal: :maximize,
  max_trials: 18,
  parallelism: 6,
  sampler: Scout.Sampler.RandomSearch,
  pruner: Scout.Pruner.Hyperband,
  pruner_opts: %{eta: 3, max_resource: 27, warmup_peers: 6},
  search_space: fn _ix -> %{x: :rand.uniform()} end,
  objective: fn %{x: x}, report ->
    s0 = 1.0 - :math.pow(x - 0.2, 2); if report.(s0, 0) == :prune, do: {:pruned, s0}
    s1 = 1.0 - :math.pow(x - 0.6, 2); if report.(s1, 1) == :prune, do: {:pruned, s1}
    s2 = 1.0 - :math.pow(x - 0.9, 2); _ = report.(s2, 2)
    {:ok, s2, %{}}
  end
}

{:ok, best} = Scout.run(study)
IO.inspect(best, label: "BEST")
IO.inspect(Scout.Status.status(study.id), label: "STATUS")
```

## Notes
- Swap `Scout.Store.ETS` for Ecto/Oban when you want durable/distributed trials.
- `Scout.Pruner.Hyperband` keeps top 1/η peers per rung (goal‑aware).
- Add LiveView on top of `Scout.Status.status/1` for real‑time dashboards.
