defmodule Scout.Telemetry do
  def emit(event, measurements, meta), do: :telemetry.execute([:scout | List.wrap(event)], measurements, meta)
end
