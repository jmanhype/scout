defmodule Scout.Trial do
  @enforce_keys [:id, :study_id, :params, :status]
  defstruct [:id, :study_id, :params, :status, :score, :metadata, :bracket, :rung, :inserted_at, :updated_at]
end
