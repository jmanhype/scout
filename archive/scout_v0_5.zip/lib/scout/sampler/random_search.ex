defmodule Scout.Sampler.RandomSearch do
  def new(opts), do: %__MODULE__{seed: Keyword.get(opts, :seed, :erlang.monotonic_time())}
  defstruct [:seed]
  def suggest(_study, _history, search_space_fun, ix), do: search_space_fun.(ix)
end
