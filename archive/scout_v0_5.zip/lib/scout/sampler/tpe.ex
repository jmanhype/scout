defmodule Scout.Sampler.TPE do
  @moduledoc "Placeholder TPE sampler; replace with full implementation."
  def new(_opts), do: %__MODULE__{}
  defstruct []
  def suggest(_study, _history, space_fun, ix), do: space_fun.(ix)
end
