defmodule Scout.Status do
  alias Scout.Store.ETS
  def status(study_id) do
    with {:ok, study} <- ETS.get_study(study_id) do
      trials = ETS.trials_for_study(study_id)
      %{
        study_id: study_id, goal: study.goal,
        counts: %{
          running: Enum.count(trials, &(&1.status == :running)),
          completed: Enum.count(trials, &(&1.status == :completed)),
          pruned: Enum.count(trials, &(&1.status == :pruned)),
          failed: Enum.count(trials, &(&1.status == :failed))
        }
      }
    else _ -> %{error: :not_found} end
  end
end
