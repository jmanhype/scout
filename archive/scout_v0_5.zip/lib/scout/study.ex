defmodule Scout.Study do
  @enforce_keys [:id, :goal, :max_trials, :parallelism, :sampler, :pruner, :search_space, :objective]
  defstruct [:id, :goal, :max_trials, :parallelism, :sampler, :sampler_opts, :pruner, :pruner_opts, :search_space, :objective]
  @type goal :: :maximize | :minimize
  @type t :: %__MODULE__{
    id: String.t(), goal: goal(), max_trials: pos_integer(), parallelism: pos_integer(),
    sampler: module(), sampler_opts: map() | nil, pruner: module() | nil, pruner_opts: map() | nil,
    search_space: (non_neg_integer() -> map()),
    objective: (map(), (number(), non_neg_integer() -> :ok | :prune) -> {:ok, number(), map()} | {:pruned, number()} | {:error, term()})
  }
end
