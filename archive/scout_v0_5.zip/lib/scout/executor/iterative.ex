defmodule Scout.Executor.Iterative do
  alias Scout.{Study}
  alias Scout.Executor.Local

  def run(%Study{} = study) do
    sampler = build(study.sampler, study.sampler_opts || [])
    pruner = if study.pruner, do: build(study.pruner, study.pruner_opts || %{}), else: nil
    Local.run(study, sampler, pruner)
  end

  defp build(mod, opts), do: if function_exported?(mod, :new, 1), do: mod.new(opts), else: mod
end
