defmodule Scout.Executor.Local do
  alias Scout.{Study}
  alias Scout.Store.ETS

  def run(%Study{} = study, sampler, pruner) do
    1..study.max_trials
    |> Task.async_stream(fn ix -> one(study, sampler, pruner, ix) end, max_concurrency: study.parallelism, timeout: :infinity)
    |> Stream.run()
    best(study)
  end

  defp one(study, sampler, pruner, ix) do
    params = sampler.suggest(study, [], study.search_space, ix)
    trial = %Scout.Trial{id: ETS.next_trial_id(), study_id: study.id, params: params, status: :running,
                         inserted_at: System.system_time(:millisecond), updated_at: System.system_time(:millisecond)}
    ETS.insert_trial(trial)

    report = fn score, rung ->
      bracket = 0
      ETS.record_observation(study.id, bracket, rung, trial.id, score)
      case keep?(pruner, study, bracket, rung, trial.id, score) do
        :keep -> :ok
        :prune -> ETS.mark_pruned(study.id, bracket, rung, trial.id); ETS.update_trial(%{trial | status: :pruned, score: score}); :prune
      end
    end

    case study.objective.(params, report) do
      {:ok, score, meta} -> ETS.update_trial(%{trial | status: :completed, score: score, metadata: meta})
      {:pruned, score} -> ETS.update_trial(%{trial | status: :pruned, score: score})
      {:error, reason} -> ETS.update_trial(%{trial | status: :failed, metadata: %{error: inspect(reason)}})
    end
  end

  defp keep?(nil, _s, _b, _r, _t, _sc), do: :keep
  defp keep?(pruner, s, b, r, t, sc), do: pruner.keep?(s, b, r, t, sc)

  defp best(study) do
    sorter = case study.goal do :maximize -> &>=/2; :minimize -> &<=/2 end
    trials = ETS.trials_for_study(study.id) |> Enum.filter(& &1.score)
    case Enum.sort_by(trials, & &1.score, sorter) do
      [best | _] -> {:ok, %{params: best.params, score: best.score, trial_id: best.id}}
      _ -> {:error, :no_trials}
    end
  end
end
