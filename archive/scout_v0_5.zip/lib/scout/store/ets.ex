defmodule Scout.Store.ETS do
  use GenServer
  alias Scout.{Study, Trial}
  @studies :scout_studies
  @trials :scout_trials
  @obs :scout_obs
  @prunes :scout_prunes
  def start_link(_), do: GenServer.start_link(__MODULE__, [], name: __MODULE__)
  def put_study(%Study{} = study), do: :ets.insert(@studies, {study.id, study}) && :ok
  def get_study(study_id), do: case :ets.lookup(@studies, study_id) do [{^study_id, s}] -> {:ok, s}; _ -> {:error, :not_found} end
  def next_trial_id, do: :crypto.strong_rand_bytes(12) |> Base.encode16(case: :lower)
  def insert_trial(%Trial{} = t), do: :ets.insert(@trials, {t.id, t}) && :ok
  def update_trial(%Trial{} = t), do: :ets.insert(@trials, {t.id, %{t | updated_at: System.system_time(:millisecond)}}) && :ok
  def fetch_trial(id), do: case :ets.lookup(@trials, id) do [{^id, t}] -> {:ok, t}; _ -> {:error, :not_found} end
  def trials_for_study(study_id), do: :ets.match_object(@trials, {:_, %Trial{study_id: study_id}}) |> Enum.map(fn {_k, v} -> v end)
  def record_observation(study_id, bracket, rung, trial_id, score), do: :ets.insert(@obs, {{study_id, bracket, rung, trial_id}, score}) && :ok
  def observations(study_id, bracket, rung), do:
    :ets.match_object(@obs, {{study_id, bracket, rung, :_}, :"$1"}) |> Enum.map(fn {{_,_,_,tid}, s} -> {tid, s} end)
  def mark_pruned(study_id, bracket, rung, trial_id), do: :ets.insert(@prunes, {{study_id, bracket, rung, trial_id}, true}) && :ok
  def pruned?(study_id, bracket, rung, trial_id), do: :ets.lookup(@prunes, {study_id, bracket, rung, trial_id}) != []
  @impl true
  def init(_) do
    :ets.new(@studies, [:set, :named_table, :public, read_concurrency: true])
    :ets.new(@trials, [:set, :named_table, :public, write_concurrency: true])
    :ets.new(@obs, [:set, :named_table, :public, write_concurrency: true])
    :ets.new(@prunes, [:set, :named_table, :public, write_concurrency: true])
    {:ok, %{}}
  end
end
