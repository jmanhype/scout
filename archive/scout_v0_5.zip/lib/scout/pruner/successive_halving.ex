defmodule Scout.Pruner.SuccessiveHalving do
  alias Scout.Store.ETS
  def new(opts), do: %{eta: Map.get(opts, :eta, 3), warmup_peers: Map.get(opts, :warmup_peers, 6)}
  def keep?(study, bracket, rung, trial_id, score) do
    cfg = new(%{})
    peers = ETS.observations(study.id, bracket, rung)
    if length(peers) < cfg.warmup_peers do
      :keep
    else
      sorter = case study.goal do :maximize -> &>=/2; :minimize -> &<=/2 end
      sorted = Enum.sort_by(peers, fn {_tid, s} -> s end, sorter)
      keep_n = max(1, div(length(sorted), cfg.eta))
      {kept, _} = Enum.split(sorted, keep_n)
      if Enum.any?(kept, fn {tid, _} -> tid == trial_id end), do: :keep, else: :prune
    end
  end
end
