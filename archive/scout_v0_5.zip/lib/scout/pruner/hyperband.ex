defmodule Scout.Pruner.Hyperband do
  alias Scout.Store.ETS
  def new(opts), do: %{eta: Map.get(opts, :eta, 3), max_resource: Map.get(opts, :max_resource, 27), warmup_peers: Map.get(opts, :warmup_peers, 6)}
  def s_max(%{eta: eta, max_resource: r}), do: Float.floor(:math.log(r) / :math.log(eta)) |> trunc
  def assign_bracket(study_id, opts) do
    smax = s_max(opts); trials = ETS.trials_for_study(study_id); rem(length(trials), smax + 1)
  end
  def keep?(study, %{eta: eta, warmup_peers: warm}, bracket, rung, trial_id, _score) do
    peers = ETS.observations(study.id, bracket, rung)
    if length(peers) < warm, do: :keep, else: keep2(study.goal, eta, peers, trial_id)
  end
  defp keep2(:maximize, eta, peers, trial_id), do: keep_sorted(Enum.sort_by(peers, &elem(&1,1), &>=/2), eta, trial_id)
  defp keep2(:minimize, eta, peers, trial_id), do: keep_sorted(Enum.sort_by(peers, &elem(&1,1), &<=/2), eta, trial_id)
  defp keep_sorted(sorted, eta, trial_id) do
    keep_n = max(1, div(length(sorted), eta))
    {kept, _} = Enum.split(sorted, keep_n)
    if Enum.any?(kept, fn {tid, _} -> tid == trial_id end), do: :keep, else: :prune
  end
end
