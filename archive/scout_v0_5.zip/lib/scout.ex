defmodule Scout do
  alias Scout.{Study}
  alias Scout.Executor.Iterative
  alias Scout.Store.ETS
  @spec run(Study.t()) :: {:ok, map()} | {:error, term()}
  def run(%Study{} = study) do
    ETS.put_study(study)
    Iterative.run(study)
  end
end
