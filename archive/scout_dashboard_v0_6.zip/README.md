
# Scout Live Dashboard (v0.6)

A minimal Phoenix LiveView app that charts **Scout / Hyperband** studies in real time,
driven by `Scout.Status.status/1`.

## Quick start

```bash
cd scout_dashboard_v0_6
mix deps.get
iex -S mix
# open http://localhost:4050 and enter a study id, e.g. "hb-123"
```

If your Scout library is available in the same VM (e.g., umbrella or deps), export:

```elixir
# calls Scout.Status.status/1 and Scout.Status.best/1
Application.put_env(:scout_dashboard, :status_module, Scout.Status)
```

Otherwise the UI renders **synthetic** data so you can verify the dashboard.

## Integrating with an umbrella

- Move this app under `/apps/scout_dashboard`.
- In your umbrella's `mix.exs`, add `:scout_dashboard` to `apps`.
- Ensure `{:scout, in_umbrella: true}` exists (or provide a module with the same API).

## What’s implemented

- Live updates (1s) via polling `ScoutClient.status/1`.
- Per‑bracket / per‑rung table with inline SVG bar charts (completed/running/pruned).
- Sparkline of best scores over time.
- Telemetry listener scaffold (attach to `[:scout, ...]` events).

## Next

- Switch from polling to PubSub (`:telemetry` -> `Phoenix.PubSub.broadcast`).
- Add per‑trial drilldown LiveView (params, metrics, logs).
- Plug real `Scout.Status` (Ecto/Oban version) when you wire distributed execution.
