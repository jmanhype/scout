
defmodule ScoutDashboardWeb.Layouts do
  use ScoutDashboardWeb, :html

  embed_templates "layouts/*"
end
