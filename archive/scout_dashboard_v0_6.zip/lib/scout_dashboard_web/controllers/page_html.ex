
defmodule ScoutDashboardWeb.PageHTML do
  use ScoutDashboardWeb, :html
  embed_templates "page_html/*"
end
