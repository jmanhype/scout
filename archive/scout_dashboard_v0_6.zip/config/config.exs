
import Config

config :scout_dashboard, ScoutDashboardWeb.Endpoint,
  adapter: Bandit.PhoenixAdapter,
  url: [host: "localhost"],
  render_errors: [
    formats: [html: ScoutDashboardWeb.ErrorHTML, json: "error.json"],
    layout: false
  ],
  pubsub_server: ScoutDashboard.PubSub,
  live_view: [signing_salt: "r7Q6d3ko"]

if config_env() == :dev do
  config :scout_dashboard, ScoutDashboardWeb.Endpoint,
    http: [ip: {127,0,0,1}, port: 4050],
    debug_errors: true,
    code_reloader: true,
    check_origin: false,
    watchers: []
end

if config_env() == :prod do
  config :scout_dashboard, ScoutDashboardWeb.Endpoint,
    url: [host: System.get_env("HOST", "example.com"), port: 443],
    http: [ip: {0,0,0,0}, port: String.to_integer(System.get_env("PORT") || "4050")],
    secret_key_base: System.get_env("SECRET_KEY_BASE") || "CHANGE_ME"
end
