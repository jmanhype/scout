
# Scout v0.3 (durable + distributed)

**Optuna-style HPO for Elixir (OTP-native)** with:
- Ecto/Postgres storage
- Oban executor (durable, distributed)
- Deterministic seeds
- Successive Halving pruner
- Bandit sampler
- CLI for start/status/pause/resume

## Install
```bash
cp config.sample.exs config/config.exs
mix deps.get
mix ecto.create
mix ecto.migrate
iex -S mix
```

## Start a study (local)
```elixir
study = %{
  id: "demo-#{:erlang.unique_integer([:positive])}",
  goal: :maximize,
  max_trials: 20,
  parallelism: 4,
  seed: 1234,
  sampler: Scout.Sampler.Bandit,
  pruner: nil,
  search_space: fn _ -> %{temperature: :rand.uniform(), top_p: :rand.uniform()} end,
  objective: fn %{temperature: t, top_p: p} -> 1.0 - :math.pow(t - 0.2, 2) - :math.pow(p - 0.9, 2) end
}
{:ok, best} = Scout.StudyRunner.run(study)
```

## Start a study (Oban, durable)
Create `my_study.exs`:
```elixir
%{
  id: "oban-demo",
  module: MyStudy,  # durable callbacks (defined below)
  goal: :maximize,
  max_trials: 100,
  parallelism: 20,
  seed: 42,
  sampler: Scout.Sampler.Bandit,
  pruner: Scout.Pruner.SuccessiveHalving
}
```
Define module somewhere in your app (compiled code):
```elixir
defmodule MyStudy do
  def search_space(ix), do: %{temperature: :rand.uniform(), top_p: :rand.uniform()}
  def objective(%{temperature: t, top_p: p}), do: 1.0 - :math.pow(t - 0.2, 2) - :math.pow(p - 0.9, 2)
  # Or iterative: def objective(params, report), do: ...
end
```
Run:
```bash
mix scout.study start my_study.exs --executor oban
mix scout.study status oban-demo
mix scout.study pause  oban-demo
mix scout.study resume oban-demo
```

## Telemetry
- `[:scout, :study, :start|:stop]`
- `[:scout, :trial, :start|:stop|:error|:prune]`

## Next (v0.4)
- Hyperband wrapper
- TPE sampler
- LiveView dashboard
