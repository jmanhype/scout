
defmodule Scout.Sampler do
  @moduledoc "Sampling strategies for parameters."
  @callback init(opts :: map()) :: state :: term()
  @callback next(search_space_fun :: (non_neg_integer -> map()),
                 trial_ix :: non_neg_integer,
                 history :: Enumerable.t(),
                 state :: term()) :: {params :: map(), state :: term()}
end
