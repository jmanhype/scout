
defmodule Scout.Study do
  @moduledoc "Study contract (Optuna-like)."

  @type t :: %{
          id: String.t(),
          goal: :maximize | :minimize,
          max_trials: pos_integer(),
          parallelism: pos_integer(),
          seed: non_neg_integer(),
          sampler: module(), sampler_opts: map(),
          pruner: module() | nil, pruner_opts: map(),
          executor: :local | :iterative | :oban,
          search_space: (non_neg_integer -> map()),
          objective: (map() -> number() | {:ok, number(), map()} | {:error, term()})
                   | (map(), (number(), non_neg_integer -> :continue | :prune) -> any())
        }
end
