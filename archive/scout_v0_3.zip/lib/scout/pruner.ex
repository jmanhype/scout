
defmodule Scout.Pruner do
  @moduledoc "Pruning strategies for early stopping."
  @type rung :: non_neg_integer
  @callback init(opts :: map()) :: state :: term()
  @callback keep?(trial_id :: term(),
                  scores_so_far :: [number()],
                  rung :: rung,
                  context :: map(),
                  state :: term()) :: {boolean(), state :: term()}
end
