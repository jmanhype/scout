
defmodule Scout.Store do
  @moduledoc "Store facade & behaviour for studies, trials and observations."
  @callback start_link(term) :: GenServer.on_start()
  @callback put_study(study :: map()) :: :ok | {:error, term()}
  @callback set_study_status(study_id :: term(), status :: String.t()) :: :ok | {:error, term()}
  @callback get_study(study_id :: term()) :: {:ok, map()} | :error
  @callback add_trial(study_id :: term(), trial :: map()) :: {:ok, term()} | {:error, term()}
  @callback update_trial(trial_id :: term(), updates :: map()) :: :ok | {:error, term()}
  @callback record_observation(trial_id :: term(), rung :: non_neg_integer, score :: number()) :: :ok | {:error, term()}
  @callback list_trials(study_id :: term(), filters :: keyword()) :: [map()]
  @callback fetch_trial(trial_id :: term()) :: {:ok, map()} | :error

  defp adapter, do: Application.get_env(:scout, :store, Scout.Store.Ecto)

  def put_study(s), do: adapter().put_study(s)
  def set_study_status(id, st), do: adapter().set_study_status(id, st)
  def get_study(id), do: adapter().get_study(id)
  def add_trial(study_id, t), do: adapter().add_trial(study_id, t)
  def update_trial(id, u), do: adapter().update_trial(id, u)
  def record_observation(id, rung, score), do: adapter().record_observation(id, rung, score)
  def list_trials(study_id, filters \ []), do: adapter().list_trials(study_id, filters)
  def fetch_trial(id), do: adapter().fetch_trial(id)
end
