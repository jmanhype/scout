
defmodule Scout.Sampler.RandomSearch do
  @behaviour Scout.Sampler
  def init(opts), do: Map.put(%{}, :seed, opts[:seed] || System.unique_integer())
  def next(space_fun, ix, _history, state), do: {space_fun.(ix), state}
end
