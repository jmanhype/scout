
defmodule Scout.Pruner.SuccessiveHalving do
  @behaviour Scout.Pruner
  @moduledoc "Successive Halving (SHA) with warmup and percentile cutoffs."
  @defaults %{eta: 3, warmup_trials: 12}

  def init(opts), do: Map.merge(@defaults, Map.new(opts || %{}))

  def keep?(_trial_id, scores_so_far, rung, %{goal: goal, study_id: study_id}, state) do
    total_trials = length(Scout.Store.list_trials(study_id))
    if total_trials < state.warmup_trials do
      {true, state}
    else
      trials = Scout.Store.list_trials(study_id)
      rung_scores =
        trials
        |> Enum.flat_map(fn t -> if t.rung >= rung and is_number(t.score), do: [t.score], else: [] end)

      keep_fraction = :math.pow(state.eta, -max(rung, 0))
      cutoff = percentile(rung_scores, if goal == :maximize, do: 1.0 - keep_fraction, else: keep_fraction)
      current = List.last(scores_so_far) || hd(scores_so_far) || 0.0
      keep = if goal == :maximize, do: current >= cutoff, else: current <= cutoff
      {keep, state}
    end
  end

  defp percentile([], _p), do: 0.0
  defp percentile(list, p) do
    s = Enum.sort(list); k = min(max(trunc(p * (length(s) - 1)), 0), length(s) - 1); Enum.at(s, k)
  end
end
