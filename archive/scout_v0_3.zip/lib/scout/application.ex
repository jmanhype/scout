
defmodule Scout.Application do
  @moduledoc false
  use Application

  def start(_type, _args) do
    store_impl = Application.get_env(:scout, :store, Scout.Store.Ecto)

    children = [
      Scout.Repo,
      {Oban, Application.get_env(:scout, Oban, [])},
      {store_impl, []}
    ]

    Supervisor.start_link(children, strategy: :one_for_one, name: __MODULE__)
  end
end
