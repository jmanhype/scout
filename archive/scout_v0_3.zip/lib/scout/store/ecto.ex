
defmodule Scout.Store.Ecto do
  @moduledoc "Ecto-backed store (durable)."
  @behaviour Scout.Store
  use GenServer
  import Ecto.Query
  alias Scout.Repo

  def start_link(_), do: GenServer.start_link(__MODULE__, %{}, name: __MODULE__)
  def init(state), do: {:ok, state}

  @impl true
  def put_study(%{id: id} = study) do
    meta = Map.drop(study, [:id])
    changes = %{id: id, meta: meta, status: meta[:status] || "running"}
    Repo.insert!(%Scout.Store.Ecto.Study{} |> Scout.Store.Ecto.Study.changeset(changes),
      on_conflict: [set: [meta: meta, updated_at: DateTime.utc_now()]], conflict_target: :id)
    :ok
  end

  @impl true
  def set_study_status(id, status) do
    from(s in Scout.Store.Ecto.Study, where: s.id == ^id) |> Repo.update_all(set: [status: status])
    :ok
  end

  @impl true
  def get_study(id) do
    case Repo.get(Scout.Store.Ecto.Study, id) do
      nil -> :error
      %Scout.Store.Ecto.Study{meta: meta, status: st} -> {:ok, Map.merge(meta, %{id: id, status: st})}
    end
  end

  @impl true
  def add_trial(study_id, trial) do
    rec = Repo.insert!(%Scout.Store.Ecto.Trial{
      study_id: study_id, status: to_string(trial.status || :pending),
      params: trial.params, rung: trial.rung, score: trial.score,
      metrics: trial.metrics, error: trial.error, seed: trial.seed
    })
    {:ok, rec.id}
  end

  @impl true
  def update_trial(id, updates) do
    with %Scout.Store.Ecto.Trial{} = t <- Repo.get(Scout.Store.Ecto.Trial, id) do
      changes = %{
        status: updates[:status] && to_string(updates[:status]) || t.status,
        rung: Map.get(updates, :rung, t.rung),
        score: Map.get(updates, :score, t.score),
        metrics: Map.get(updates, :metrics, t.metrics),
        error: Map.get(updates, :error, t.error)
      }
      Repo.update!(Ecto.Changeset.change(t, changes)); :ok
    else
      _ -> {:error, :not_found}
    end
  end

  @impl true
  def record_observation(trial_id, rung, score) do
    Repo.insert!(%Scout.Store.Ecto.Observation{trial_id: trial_id, rung: rung, score: score}); :ok
  end

  @impl true
  def list_trials(study_id, _filters) do
    Repo.all(from t in Scout.Store.Ecto.Trial, where: t.study_id == ^study_id, order_by: [asc: t.id])
    |> Enum.map(fn t -> %{id: t.id, study: t.study_id, params: t.params, status: String.to_atom(t.status), rung: t.rung, score: t.score, metrics: t.metrics, error: t.error, seed: t.seed} end)
  end

  @impl true
  def fetch_trial(id) do
    case Repo.get(Scout.Store.Ecto.Trial, id) do
      nil -> :error
      t -> {:ok, %{id: t.id, study: t.study_id, params: t.params, status: String.to_atom(t.status), rung: t.rung, score: t.score, metrics: t.metrics, error: t.error, seed: t.seed}}
    end
  end
end
