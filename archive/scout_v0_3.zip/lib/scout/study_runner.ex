
defmodule Scout.StudyRunner do
  @moduledoc "Run a study using Local/Iterative/Oban executors."
  def run(%{executor: :oban} = study), do: Scout.Executor.Oban.run(study)
  def run(study) do
    case :erlang.fun_info(study.objective)[:arity] do
      2 -> Scout.Executor.Iterative.run(study)
      _ -> Scout.Executor.Local.run(study)
    end
  end
end
