
defmodule Scout.Trial do
  @moduledoc "In-memory representation of a single optimization trial."
  @enforce_keys [:id, :study, :params]
  defstruct [:id, :study, :params,
             status: :pending,
             rung: 0,
             scores: [],
             metrics: %{},
             score: nil,
             error: nil,
             started_at: nil,
             finished_at: nil, seed: nil]
end
