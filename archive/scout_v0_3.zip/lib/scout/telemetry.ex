
defmodule Scout.Telemetry do
  @moduledoc false
  def study_event(name, measurements, meta), do: :telemetry.execute([:scout, :study, name], measurements, meta)
  def trial_event(name, measurements, meta),  do: :telemetry.execute([:scout, :trial, name], measurements, meta)
end
